#!/usr/bin/env python

def welcome():
    print('Welcome to the Brain Games!')

def main():
    welcome()

if __name__ == '__main__':
    main()